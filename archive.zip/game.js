/**
 * Breakout Game - Main JavaScript File
 * Implements core game mechanics using HTML5 Canvas
 * Enhanced with UI elements, sound effects, particle effects, and localStorage
 */

// Wait for the DOM to be fully loaded before initializing the game
document.addEventListener('DOMContentLoaded', () => {
    // Canvas setup
    const canvas = document.getElementById('gameCanvas');
    const ctx = canvas.getContext('2d');
    
    // Game elements
    let ball, paddle, bricks, particles = [];
    
    // Game state variables
    let score = 0;
    let highScore = 0;
    let lives = 3;
    let level = 1;
    let maxLevel = 5;
    let gameRunning = false;
    let gamePaused = false;
    let ballReleased = false;
    let levelTransitioning = false;
    let levelTransitionTimer = null;
    let showingTutorial = false;
    let firstTimePlayer = true;
    
    // DOM elements
    const scoreElement = document.getElementById('score');
    const livesElement = document.getElementById('lives');
    const levelElement = document.getElementById('level');
    const finalScoreElement = document.getElementById('finalScore');
    const highScoreElement = document.getElementById('highScore');
    const victoryScoreElement = document.getElementById('victoryScore');
    const victoryHighScoreElement = document.getElementById('victoryHighScore');
    const transitionLevelElement = document.getElementById('transitionLevel');
    
    // Overlay elements
    const gameOverOverlay = document.getElementById('gameOverOverlay');
    const victoryOverlay = document.getElementById('victoryOverlay');
    const tutorialOverlay = document.getElementById('tutorialOverlay');
    const pauseOverlay = document.getElementById('pauseOverlay');
    const levelTransitionOverlay = document.getElementById('levelTransitionOverlay');
    
    // Button elements
    const startButton = document.getElementById('startButton');
    const pauseButton = document.getElementById('pauseButton');
    const restartButton = document.getElementById('restartButton');
    const restartFromGameOverButton = document.getElementById('restartFromGameOver');
    const restartFromVictoryButton = document.getElementById('restartFromVictory');
    const dismissTutorialButton = document.getElementById('dismissTutorial');
    
    // Set current year in footer
    document.getElementById('currentYear').textContent = new Date().getFullYear();
    
    // Game constants
    const BALL_RADIUS = 10;
    const PADDLE_HEIGHT = 15;
    const PADDLE_WIDTH = 100;
    const BRICK_ROW_COUNT = 5;
    const BRICK_COLUMN_COUNT = 9;
    const BRICK_WIDTH = 75;
    const BRICK_HEIGHT = 20;
    const BRICK_PADDING = 10;
    const BRICK_OFFSET_TOP = 60;
    const BRICK_OFFSET_LEFT = 30;
    const BALL_SPEED_INITIAL = 5;
    const PADDLE_SPEED = 7;
    const PARTICLE_COUNT = 15;
    const PARTICLE_GRAVITY = 0.1;
    const PARTICLE_FRICTION = 0.98;
    const PARTICLE_LIFESPAN = 50;
    
    // Brick colors by row (for different point values)
    const BRICK_COLORS = [
        '#FF6B6B', // Red - 5 points
        '#FFD166', // Yellow - 4 points
        '#06D6A0', // Green - 3 points
        '#118AB2', // Blue - 2 points
        '#073B4C'  // Navy - 1 point
    ];
    
    // Brick point values by row
    const BRICK_POINTS = [5, 4, 3, 2, 1];
    
    // Game states
    const GAME_STATE = {
        MENU: 'menu',
        PLAYING: 'playing',
        PAUSED: 'paused',
        GAME_OVER: 'gameOver',
        VICTORY: 'victory',
        LEVEL_TRANSITION: 'levelTransition',
        TUTORIAL: 'tutorial'
    };
    
    let currentGameState = GAME_STATE.MENU;
    
    // Sound effects
    const sounds = {
        'paddle': new Audio('assets/sounds/paddle.mp3'),
        'brick': new Audio('assets/sounds/brick.mp3'),
        'wall': new Audio('assets/sounds/wall.mp3'),
        'life-lost': new Audio('assets/sounds/life-lost.mp3'),
        'game-over': new Audio('assets/sounds/game-over.mp3'),
        'win': new Audio('assets/sounds/win.mp3'),
        'level-up': new Audio('assets/sounds/level-up.mp3')
    };
    
    // Particle class for visual effects
    class Particle {
        constructor(x, y, color) {
            this.x = x;
            this.y = y;
            this.size = Math.random() * 3 + 2;
            this.speedX = Math.random() * 6 - 3;
            this.speedY = Math.random() * 6 - 3;
            this.color = color;
            this.alpha = 1;
            this.life = PARTICLE_LIFESPAN;
        }
        
        update() {
            this.speedX *= PARTICLE_FRICTION;
            this.speedY *= PARTICLE_FRICTION;
            this.speedY += PARTICLE_GRAVITY;
            this.x += this.speedX;
            this.y += this.speedY;
            this.life--;
            this.alpha = this.life / PARTICLE_LIFESPAN;
        }
        
        draw() {
            ctx.globalAlpha = this.alpha;
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
            ctx.fillStyle = this.color;
            ctx.fill();
            ctx.globalAlpha = 1;
        }
    }
    
    // Initialize game
    function init() {
        // Clear any existing timers
        if (levelTransitionTimer) {
            clearTimeout(levelTransitionTimer);
            levelTransitionTimer = null;
        }
        
        // Reset game state
        score = 0;
        lives = 3;
        level = 1;
        gameRunning = false;
        gamePaused = false;
        ballReleased = false;
        levelTransitioning = false;
        particles = [];
        
        // Hide all overlays
        hideAllOverlays();
        
        // Load high score from localStorage
        loadHighScore();
        
        // Update UI
        updateScoreDisplay();
        
        // Create game objects
        createBall();
        createPaddle();
        createBricks();
        
        // Set initial game state
        currentGameState = GAME_STATE.MENU;
        
        // Check if this is the first time playing
        checkFirstTimePlayer();
        
        // Draw initial game state
        draw();
    }
    
    // Hide all overlay elements
    function hideAllOverlays() {
        gameOverOverlay.classList.remove('active');
        victoryOverlay.classList.remove('active');
        tutorialOverlay.classList.remove('active');
        pauseOverlay.classList.remove('active');
        levelTransitionOverlay.classList.remove('active');
    }
    
    // Show a specific overlay
    function showOverlay(overlay) {
        hideAllOverlays();
        overlay.classList.add('active');
    }
    
    // Check if this is the first time playing
    function checkFirstTimePlayer() {
        firstTimePlayer = localStorage.getItem('breakoutPlayed') !== 'true';
        if (firstTimePlayer) {
            showingTutorial = true;
            currentGameState = GAME_STATE.TUTORIAL;
            showOverlay(tutorialOverlay);
        }
    }
    
    // Mark that the player has played before
    function markAsPlayed() {
        localStorage.setItem('breakoutPlayed', 'true');
        firstTimePlayer = false;
    }
    
    // Load high score from localStorage
    function loadHighScore() {
        const savedHighScore = localStorage.getItem('breakoutHighScore');
        if (savedHighScore) {
            highScore = parseInt(savedHighScore);
        }
    }
    
    // Save high score to localStorage
    function saveHighScore() {
        if (score > highScore) {
            highScore = score;
            localStorage.setItem('breakoutHighScore', highScore.toString());
            return true;
        }
        return false;
    }
    
    // Create the ball object
    function createBall() {
        const speedMultiplier = 1 + (level - 1) * 0.2; // Increase speed with level
        ball = {
            x: canvas.width / 2,
            y: canvas.height - PADDLE_HEIGHT - BALL_RADIUS - 10,
            dx: BALL_SPEED_INITIAL * speedMultiplier * (Math.random() > 0.5 ? 1 : -1),
            dy: -BALL_SPEED_INITIAL * speedMultiplier,
            radius: BALL_RADIUS,
            speed: BALL_SPEED_INITIAL * speedMultiplier
        };
    }
    
    // Create the paddle object
    function createPaddle() {
        paddle = {
            x: (canvas.width - PADDLE_WIDTH) / 2,
            y: canvas.height - PADDLE_HEIGHT - 10,
            width: PADDLE_WIDTH,
            height: PADDLE_HEIGHT,
            dx: 0,
            speed: PADDLE_SPEED
        };
    }
    
    // Create the brick grid
    function createBricks() {
        bricks = [];
        
        for (let r = 0; r < BRICK_ROW_COUNT; r++) {
            bricks[r] = [];
            for (let c = 0; c < BRICK_COLUMN_COUNT; c++) {
                const brickX = c * (BRICK_WIDTH + BRICK_PADDING) + BRICK_OFFSET_LEFT;
                const brickY = r * (BRICK_HEIGHT + BRICK_PADDING) + BRICK_OFFSET_TOP;
                bricks[r][c] = { 
                    x: brickX, 
                    y: brickY, 
                    status: 1, 
                    color: BRICK_COLORS[r],
                    points: BRICK_POINTS[r]
                };
            }
        }
    }
    
    // Create particles at a specific position with a specific color
    function createParticles(x, y, color) {
        for (let i = 0; i < PARTICLE_COUNT; i++) {
            particles.push(new Particle(x, y, color));
        }
    }
    
    // Update particles
    function updateParticles() {
        for (let i = particles.length - 1; i >= 0; i--) {
            particles[i].update();
            
            // Remove dead particles
            if (particles[i].life <= 0) {
                particles.splice(i, 1);
            }
        }
    }
    
    // Draw particles
    function drawParticles() {
        particles.forEach(particle => {
            particle.draw();
        });
    }
    
    // Draw the ball
    function drawBall() {
        ctx.beginPath();
        ctx.arc(ball.x, ball.y, ball.radius, 0, Math.PI * 2);
        ctx.fillStyle = '#FFFFFF';
        ctx.fill();
        ctx.closePath();
        
        // Add a subtle shadow
        ctx.beginPath();
        ctx.arc(ball.x, ball.y, ball.radius + 2, 0, Math.PI * 2);
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.3)';
        ctx.lineWidth = 1;
        ctx.stroke();
        ctx.closePath();
    }
    
    // Draw the paddle
    function drawPaddle() {
        ctx.beginPath();
        ctx.rect(paddle.x, paddle.y, paddle.width, paddle.height);
        ctx.fillStyle = '#4A6CFF';
        ctx.fill();
        ctx.closePath();
        
        // Add a gradient/shine effect to the paddle
        const gradient = ctx.createLinearGradient(
            paddle.x, paddle.y, 
            paddle.x, paddle.y + paddle.height
        );
        gradient.addColorStop(0, 'rgba(255, 255, 255, 0.3)');
        gradient.addColorStop(1, 'rgba(255, 255, 255, 0)');
        
        ctx.beginPath();
        ctx.rect(paddle.x, paddle.y, paddle.width, paddle.height / 2);
        ctx.fillStyle = gradient;
        ctx.fill();
        ctx.closePath();
    }
    
    // Draw the bricks
    function drawBricks() {
        for (let r = 0; r < BRICK_ROW_COUNT; r++) {
            for (let c = 0; c < BRICK_COLUMN_COUNT; c++) {
                const brick = bricks[r][c];
                if (brick.status === 1) {
                    ctx.beginPath();
                    ctx.rect(brick.x, brick.y, BRICK_WIDTH, BRICK_HEIGHT);
                    ctx.fillStyle = brick.color;
                    ctx.fill();
                    ctx.strokeStyle = 'rgba(0, 0, 0, 0.3)';
                    ctx.lineWidth = 1;
                    ctx.stroke();
                    ctx.closePath();
                    
                    // Add a gradient/shine effect to the bricks
                    const gradient = ctx.createLinearGradient(
                        brick.x, brick.y, 
                        brick.x, brick.y + BRICK_HEIGHT
                    );
                    gradient.addColorStop(0, 'rgba(255, 255, 255, 0.3)');
                    gradient.addColorStop(1, 'rgba(255, 255, 255, 0)');
                    
                    ctx.beginPath();
                    ctx.rect(brick.x, brick.y, BRICK_WIDTH, BRICK_HEIGHT / 2);
                    ctx.fillStyle = gradient;
                    ctx.fill();
                    ctx.closePath();
                }
            }
        }
    }
    
    // Draw game elements
    function draw() {
        // Clear the canvas
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        // Draw background
        drawBackground();
        
        // Draw game elements
        drawBricks();
        drawPaddle();
        drawBall();
        drawParticles();
        
        // Draw score, lives, level, and high score
        drawGameInfo();
    }
    
    // Draw background with subtle pattern
    function drawBackground() {
        // Fill background
        ctx.fillStyle = '#1a1a2e';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        
        // Draw subtle grid pattern
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
        ctx.lineWidth = 1;
        
        // Vertical lines
        for (let x = 0; x < canvas.width; x += 20) {
            ctx.beginPath();
            ctx.moveTo(x, 0);
            ctx.lineTo(x, canvas.height);
            ctx.stroke();
        }
        
        // Horizontal lines
        for (let y = 0; y < canvas.height; y += 20) {
            ctx.beginPath();
            ctx.moveTo(0, y);
            ctx.lineTo(canvas.width, y);
            ctx.stroke();
        }
    }
    
    // Draw game information (score, lives, level)
    function drawGameInfo() {
        // Draw high score
        ctx.font = '16px Arial';
        ctx.fillStyle = '#FFD166';
        ctx.textAlign = 'right';
        ctx.fillText(`High Score: ${highScore}`, canvas.width - 20, 30);
    }
    
    // Update ball position
    function updateBall() {
        if (!ballReleased) {
            // Ball sticks to paddle before release
            ball.x = paddle.x + paddle.width / 2;
            return;
        }
        
        // Move the ball
        ball.x += ball.dx;
        ball.y += ball.dy;
        
        // Wall collision detection
        // Right and left walls
        if (ball.x + ball.radius > canvas.width || ball.x - ball.radius < 0) {
            ball.dx = -ball.dx;
            playSound('wall');
            
            // Create particles at the point of collision
            if (ball.x + ball.radius > canvas.width) {
                createParticles(canvas.width - ball.radius, ball.y, '#FFFFFF');
            } else {
                createParticles(ball.radius, ball.y, '#FFFFFF');
            }
        }
        
        // Top wall
        if (ball.y - ball.radius < 0) {
            ball.dy = -ball.dy;
            playSound('wall');
            createParticles(ball.x, ball.radius, '#FFFFFF');
        }
        
        // Bottom wall - lose a life
        if (ball.y + ball.radius > canvas.height) {
            lives--;
            livesElement.textContent = lives;
            playSound('life-lost');
            
            // Create particles for life lost
            createParticles(ball.x, canvas.height - ball.radius, '#FF6B6B');
            
            if (lives <= 0) {
                gameOver(false);
                return;
            }
            
            // Reset ball and paddle
            ballReleased = false;
            createBall();
            createPaddle();
        }
        
        // Paddle collision detection
        if (
            ball.y + ball.radius > paddle.y &&
            ball.y - ball.radius < paddle.y + paddle.height &&
            ball.x > paddle.x &&
            ball.x < paddle.x + paddle.width
        ) {
            // Calculate bounce angle based on where ball hits paddle
            // Middle of paddle = straight up, edges = angled bounce
            const hitPoint = (ball.x - (paddle.x + paddle.width / 2)) / (paddle.width / 2);
            
            // Limit the angle to avoid horizontal bouncing
            const bounceAngle = hitPoint * Math.PI / 3; // Max 60 degree angle
            
            // Calculate new velocity
            ball.dy = -ball.speed * Math.cos(bounceAngle);
            ball.dx = ball.speed * Math.sin(bounceAngle);
            
            // Create particles at the point of collision
            createParticles(ball.x, paddle.y, '#4A6CFF');
            
            playSound('paddle');
        }
        
        // Brick collision detection
        brickCollisionDetection();
    }
    
    // Update paddle position
    function updatePaddle() {
        paddle.x += paddle.dx;
        
        // Keep paddle within canvas boundaries
        if (paddle.x < 0) {
            paddle.x = 0;
        } else if (paddle.x + paddle.width > canvas.width) {
            paddle.x = canvas.width - paddle.width;
        }
    }
    
    // Detect collisions between ball and bricks
    function brickCollisionDetection() {
        let bricksRemaining = 0;
        
        for (let r = 0; r < BRICK_ROW_COUNT; r++) {
            for (let c = 0; c < BRICK_COLUMN_COUNT; c++) {
                const brick = bricks[r][c];
                
                if (brick.status === 1) {
                    bricksRemaining++;
                    
                    // Check for collision with improved accuracy accounting for ball radius
                    if (
                        ball.x + ball.radius > brick.x &&
                        ball.x - ball.radius < brick.x + BRICK_WIDTH &&
                        ball.y + ball.radius > brick.y &&
                        ball.y - ball.radius < brick.y + BRICK_HEIGHT
                    ) {
                        // Determine which side of the brick was hit for more realistic bouncing
                        const centerX = brick.x + BRICK_WIDTH / 2;
                        const centerY = brick.y + BRICK_HEIGHT / 2;
                        const dx = Math.abs(ball.x - centerX);
                        const dy = Math.abs(ball.y - centerY);
                        
                        // If horizontal distance is greater, ball hit left/right side
                        if (dx / (BRICK_WIDTH / 2) > dy / (BRICK_HEIGHT / 2)) {
                            ball.dx = -ball.dx;
                        } else {
                            ball.dy = -ball.dy;
                        }
                        
                        brick.status = 0;
                        score += brick.points;
                        updateScoreDisplay();
                        
                        // Create particles at the point of collision
                        createParticles(ball.x, ball.y, brick.color);
                        
                        playSound('brick');
                        
                        // Check if all bricks are destroyed
                        if (bricksRemaining === 1) {
                            // Level completed
                            if (level < maxLevel) {
                                levelUp();
                            } else {
                                victory();
                            }
                            return; // Exit the function to prevent further updates
                        }
                    }
                }
            }
        }
    }
    
    // Update score display
    function updateScoreDisplay() {
        scoreElement.textContent = score;
        livesElement.textContent = lives;
        levelElement.textContent = level;
        
        // Update final score displays
        finalScoreElement.textContent = score;
        victoryScoreElement.textContent = score;
        
        // Update high score displays
        highScoreElement.textContent = highScore;
        victoryHighScoreElement.textContent = highScore;
        
        // Update level transition display
        transitionLevelElement.textContent = level;
    }
    
    // Level up
    function levelUp() {
        // Stop the game loop by setting appropriate flags
        levelTransitioning = true;
        currentGameState = GAME_STATE.LEVEL_TRANSITION;
        
        // Increment level
        level++;
        updateScoreDisplay();
        
        // Show level transition overlay
        showOverlay(levelTransitionOverlay);
        
        // Play level up sound
        playSound('level-up');
        
        // First timeout: wait and then set up the new level
        levelTransitionTimer = setTimeout(() => {
            // Reset game objects for new level
            ballReleased = false;
            createBall();
            createPaddle();
            createBricks();
            
            // Second timeout: wait and then resume the game
            levelTransitionTimer = setTimeout(() => {
                // Hide level transition overlay
                hideAllOverlays();
                
                // Resume game
                levelTransitioning = false;
                currentGameState = GAME_STATE.PLAYING;
                
                levelTransitionTimer = null;
            }, 1500);
        }, 2000);
    }
    
    // Victory - player completed all levels
    function victory() {
        gameRunning = false;
        currentGameState = GAME_STATE.VICTORY;
        
        // Save high score
        const isNewHighScore = saveHighScore();
        
        // Update high score display
        updateScoreDisplay();
        
        // Show victory overlay
        showOverlay(victoryOverlay);
        
        // Play victory sound
        playSound('win');
    }
    
    // Game over
    function gameOver(won) {
        gameRunning = false;
        currentGameState = won ? GAME_STATE.VICTORY : GAME_STATE.GAME_OVER;
        
        // Save high score
        const isNewHighScore = saveHighScore();
        
        // Update high score display
        updateScoreDisplay();
        
        // Show appropriate overlay
        if (won) {
            showOverlay(victoryOverlay);
        } else {
            showOverlay(gameOverOverlay);
        }
        
        // Play appropriate sound
        playSound(won ? 'win' : 'game-over');
    }
    
    // Main game loop
    function gameLoop() {
        if (!gameRunning) return;
        
        // Update game objects based on current state
        if (currentGameState === GAME_STATE.PLAYING) {
            updatePaddle();
            updateBall();
            updateParticles();
        }
        
        // Draw everything
        draw();
        
        // Continue the game loop
        requestAnimationFrame(gameLoop);
    }
    
    // Play sound effects
    function playSound(sound) {
        if (sounds[sound]) {
            try {
                sounds[sound].currentTime = 0;
                sounds[sound].play().catch(e => {
                    // Handle autoplay restrictions or other errors silently
                    console.log(`Error playing sound: ${e.message}`);
                });
            } catch (e) {
                // Fallback for browsers that don't support audio
                console.log(`Error playing sound: ${e.message}`);
            }
        }
    }
    
    // Handle keyboard controls
    function keyDownHandler(e) {
        if (currentGameState === GAME_STATE.TUTORIAL) {
            // Any key dismisses tutorial
            dismissTutorial();
            return;
        }
        
        if (e.key === 'Right' || e.key === 'ArrowRight') {
            paddle.dx = paddle.speed;
        } else if (e.key === 'Left' || e.key === 'ArrowLeft') {
            paddle.dx = -paddle.speed;
        } else if (e.key === ' ' || e.key === 'Spacebar') {
            // Space bar releases the ball
            if (gameRunning && !ballReleased && currentGameState === GAME_STATE.PLAYING) {
                ballReleased = true;
            }
        } else if (e.key === 'p' || e.key === 'P') {
            // P key toggles pause
            togglePause();
        }
    }
    
    function keyUpHandler(e) {
        if (
            e.key === 'Right' ||
            e.key === 'ArrowRight' ||
            e.key === 'Left' ||
            e.key === 'ArrowLeft'
        ) {
            paddle.dx = 0;
        }
    }
    
    // Handle mouse controls
    function mouseMoveHandler(e) {
        const relativeX = e.clientX - canvas.offsetLeft;
        if (relativeX > 0 && relativeX < canvas.width) {
            paddle.x = relativeX - paddle.width / 2;
        }
    }
    
    // Handle mouse click
    function mouseClickHandler(e) {
        if (currentGameState === GAME_STATE.TUTORIAL) {
            dismissTutorial();
        } else if (gameRunning && !ballReleased && currentGameState === GAME_STATE.PLAYING) {
            ballReleased = true;
        }
    }
    
    // Dismiss tutorial
    function dismissTutorial() {
        showingTutorial = false;
        hideAllOverlays();
        currentGameState = GAME_STATE.MENU;
        markAsPlayed();
    }
    
    // Toggle pause state
    function togglePause() {
        if (!gameRunning) return;
        
        if (currentGameState === GAME_STATE.PLAYING) {
            currentGameState = GAME_STATE.PAUSED;
            showOverlay(pauseOverlay);
        } else if (currentGameState === GAME_STATE.PAUSED) {
            currentGameState = GAME_STATE.PLAYING;
            hideAllOverlays();
            requestAnimationFrame(gameLoop);
        }
    }
    
    // Handle touch controls for mobile devices
    function touchMoveHandler(e) {
        if (e.touches.length > 0) {
            const relativeX = e.touches[0].clientX - canvas.offsetLeft;
            if (relativeX > 0 && relativeX < canvas.width) {
                paddle.x = relativeX - paddle.width / 2;
            }
            e.preventDefault();
        }
    }
    
    // Handle touch tap to release ball
    function touchStartHandler(e) {
        if (currentGameState === GAME_STATE.TUTORIAL) {
            dismissTutorial();
            e.preventDefault();
        } else if (gameRunning && !ballReleased && currentGameState === GAME_STATE.PLAYING) {
            ballReleased = true;
            e.preventDefault();
        }
    }
    
    // Handle window resize
    function resizeCanvas() {
        const container = document.querySelector('.canvas-container');
        const containerWidth = container.clientWidth;
        
        // Maintain aspect ratio
        const aspectRatio = canvas.height / canvas.width;
        const newWidth = Math.min(containerWidth, 800);
        const newHeight = newWidth * aspectRatio;
        
        // Update canvas display size (CSS)
        canvas.style.width = `${newWidth}px`;
        canvas.style.height = `${newHeight}px`;
        
        // Note: We keep the canvas internal resolution the same
        // This prevents having to recalculate game coordinates
    }
    
    // Button event handlers
    startButton.addEventListener('click', () => {
        if (currentGameState === GAME_STATE.TUTORIAL) {
            dismissTutorial();
        } else if (currentGameState === GAME_STATE.MENU) {
            // Start a new game
            gameRunning = true;
            ballReleased = false;
            currentGameState = GAME_STATE.PLAYING;
            hideAllOverlays();
            gameLoop();
            startButton.textContent = 'Resume';
        } else if (currentGameState === GAME_STATE.PAUSED) {
            // Resume the game
            currentGameState = GAME_STATE.PLAYING;
            hideAllOverlays();
            gameLoop();
        }
    });
    
    pauseButton.addEventListener('click', () => {
        togglePause();
    });
    
    restartButton.addEventListener('click', () => {
        init();
        startButton.textContent = 'Start Game';
    });
    
    // Game over and victory restart buttons
    restartFromGameOverButton.addEventListener('click', () => {
        init();
        startButton.textContent = 'Start Game';
    });
    
    restartFromVictoryButton.addEventListener('click', () => {
        init();
        startButton.textContent = 'Start Game';
    });
    
    // Tutorial dismiss button
    dismissTutorialButton.addEventListener('click', () => {
        dismissTutorial();
    });
    
    // Add event listeners
    document.addEventListener('keydown', keyDownHandler);
    document.addEventListener('keyup', keyUpHandler);
    document.addEventListener('mousemove', mouseMoveHandler);
    document.addEventListener('click', mouseClickHandler);
    document.addEventListener('touchmove', touchMoveHandler, { passive: false });
    document.addEventListener('touchstart', touchStartHandler, { passive: false });
    window.addEventListener('resize', resizeCanvas);
    
    // Initialize the game
    resizeCanvas();
    init();
});